package com.example.academicinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView studentListView;
    static List<StudentModel> stList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        studentListView = (ListView) findViewById(R.id.st_listview);
        stList = new ArrayList<StudentModel>();
//        stList.add(new StudentModel("Aminur Islam", "1805001"));
//        stList.add(new StudentModel("Imran Islam", "1805036"));
//        stList.add(new StudentModel("Ezazul Hakim", "1805026"));
//        stList.add(new StudentModel("Md. Alif Alauddin", "1805028"));
//        stList.add(new StudentModel("Faisal Shohag", "1805027"));


        String jsonString = getJSONData(MainActivity.this, "students.json");

        try {
            JSONObject students = new JSONObject(jsonString);
            JSONArray student = students.getJSONArray("students");

            for(int i=0; i<student.length(); i++){
                JSONObject std = student.getJSONObject(i);
//                System.out.println(std.getString("name"));
                String name = std.getString("name");
                String id = std.getString("id");
                String addr = std.getString("address");
                String imageUrl = std.getString("imageUrl");
                String registration = std.getString("registration");
                stList.add(new StudentModel(name, id, addr, imageUrl, registration));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        StudentAdaptar adapter = new StudentAdaptar(getBaseContext(), stList);
        studentListView.setAdapter(adapter);



        studentListView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getApplicationContext(), StudentDetailsActivity.class);
            intent.putExtra("student", position);
            startActivity(intent);
        });
    }


    public static String getJSONData(Context context, String textFileName) {
        String strJSON;
        StringBuilder buf = new StringBuilder();
        InputStream json;
        try {
            json = context.getAssets().open(textFileName);

            BufferedReader in = new BufferedReader(new InputStreamReader(json, "UTF-8"));

            while ((strJSON = in.readLine()) != null) {
                buf.append(strJSON);
            }
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return buf.toString();
    }


}