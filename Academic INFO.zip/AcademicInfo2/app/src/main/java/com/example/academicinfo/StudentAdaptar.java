package com.example.academicinfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class StudentAdaptar extends ArrayAdapter {
    List<StudentModel> studentInfo = new ArrayList<StudentModel>();

    public StudentAdaptar(@NonNull Context context, List<StudentModel> studentInfo ) {
        super(context, R.layout.list_item, studentInfo );
        this.studentInfo = studentInfo;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = null;


        if(convertView == null){
            row = inflater.inflate(R.layout.list_item, parent, false);
        } else {
            row = convertView;
        }




        TextView stName = row.findViewById(R.id.st_name);
        TextView stID = row.findViewById(R.id.st_id);
        ImageView studentImage = row.findViewById(R.id.student_image);

        stName.setText(studentInfo.get(position).getStName());
        stID.setText(studentInfo.get(position).getStID());

        Picasso.get().load(studentInfo.get(position).getImageUrl()).into(studentImage);


        return row;
    }
}
