package com.example.academicinfo;

public class StudentModel {
  String stName;
  String stID;
  String stAddress;
  String imageUrl;
  String registration;



    public StudentModel(String stName, String stID, String stAddress, String imageUrl, String registration){
      this.stName = stName;
      this.stID = stID;
      this.stAddress = stAddress;
      this.imageUrl = imageUrl;
      this.registration = registration;
  }

    public String getStName() {
        return stName;
    }

    public void setStName(String stName) {
        this.stName = stName;
    }

    public String getStID() {
        return stID;
    }

    public void setStID(String stID) {
        this.stID = stID;
    }

    public String getStAddress() {
        return stAddress;
    }

    public void setStAddress(String stAddress) {
        this.stAddress = stAddress;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }
}
