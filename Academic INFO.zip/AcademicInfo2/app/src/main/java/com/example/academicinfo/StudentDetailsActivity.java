package com.example.academicinfo;

import static com.example.academicinfo.MainActivity.stList;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class StudentDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);

        int position = getIntent().getExtras().getInt("student");

        TextView studentName =  findViewById(R.id.studentName);
        TextView studentID =  findViewById(R.id.studentID);
        TextView studentAddr = findViewById(R.id.studentAddr);
        ImageView studentImage = findViewById(R.id.profile_image);
        TextView studentReg = findViewById(R.id.StudentReg);


        studentName.setText(stList.get(position).getStName());
        studentID.setText(stList.get(position).getStID());
        studentAddr.setText(stList.get(position).getStAddress());
        studentReg.setText(stList.get(position).getRegistration());
        Picasso.get().load(stList.get(position).getImageUrl()).into(studentImage);
    }


}